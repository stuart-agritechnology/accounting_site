// src/payroll/errors.ts
