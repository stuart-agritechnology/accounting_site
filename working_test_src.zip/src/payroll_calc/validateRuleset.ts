// src/payroll/validateRuleset.ts
