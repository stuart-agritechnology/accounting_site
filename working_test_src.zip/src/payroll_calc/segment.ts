// src/payroll/segment.ts
