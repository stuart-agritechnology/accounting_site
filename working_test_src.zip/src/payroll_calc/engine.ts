// src/payroll/engine.ts
