// src/payroll/rules/overtimeHigherOf.ts
