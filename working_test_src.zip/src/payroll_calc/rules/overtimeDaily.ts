// src/payroll/rules/overtimeDaily.ts
