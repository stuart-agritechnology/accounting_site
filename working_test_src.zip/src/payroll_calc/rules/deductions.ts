// src/payroll/rules/deductions.ts
