// src/payroll/rules/miningAllowances.ts
