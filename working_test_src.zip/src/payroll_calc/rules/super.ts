// src/payroll/rules/super.ts
