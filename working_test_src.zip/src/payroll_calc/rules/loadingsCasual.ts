// src/payroll/rules/loadingsCasual.ts
