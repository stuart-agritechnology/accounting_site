// src/payroll/rules/minimumEngagement.ts
