// src/payroll/rules/toil.ts
