// src/payroll/rules/leave.ts
