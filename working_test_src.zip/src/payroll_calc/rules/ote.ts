// src/payroll/rules/ote.ts
