// src/payroll/rules/allowancesTools.ts
