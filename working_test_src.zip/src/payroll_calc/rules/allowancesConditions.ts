// src/payroll/rules/allowancesConditions.ts
