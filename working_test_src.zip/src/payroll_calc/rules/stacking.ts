// src/payroll/rules/stacking.ts
