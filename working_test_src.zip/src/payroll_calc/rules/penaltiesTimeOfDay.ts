// src/payroll/rules/penaltiesTimeOfDay.ts
