// src/payroll/rules/calloutMinimum.ts
