// src/payroll/rules/miningBonuses.ts
