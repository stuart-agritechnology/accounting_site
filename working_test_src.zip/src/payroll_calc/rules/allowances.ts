// src/payroll/rules/allowances.ts
