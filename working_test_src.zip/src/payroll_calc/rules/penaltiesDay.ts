// src/payroll/rules/penaltiesDay.ts
