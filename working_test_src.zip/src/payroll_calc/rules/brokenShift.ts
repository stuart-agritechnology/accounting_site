// src/payroll/rules/brokenShift.ts
