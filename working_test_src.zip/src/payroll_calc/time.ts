// src/payroll/time.ts
