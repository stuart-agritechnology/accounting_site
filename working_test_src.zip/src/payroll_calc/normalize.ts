// src/payroll/normalize.ts
