// src/payroll/pipeline.ts
