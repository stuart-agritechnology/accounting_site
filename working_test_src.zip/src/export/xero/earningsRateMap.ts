// src/export/xero/earningsRateMap.ts
