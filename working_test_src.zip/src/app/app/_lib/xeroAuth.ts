// src/app/app/_lib/xeroAuth.ts
import { XeroClient } from "xero-node";
import { getXeroTenant, getXeroTokens, saveXeroTenant, saveXeroTokens } from "./xeroStore";

export const XERO_SCOPES = [
  "offline_access",
  "openid",
  "profile",
  "email",

  // payroll AU timesheets + employees
  "payroll.employees",
  "payroll.timesheets",

  // ✅ needed to read PayRuns (so we can find the last posted/paid date)
  "payroll.payruns.read",

  // needed for Payroll AU PayItems (earnings rates)
  "payroll.settings",

  // sometimes needed depending on what you call later
  "accounting.settings",
];

function requireEnv(name: string) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

export function makeXeroClient() {
  const clientId = requireEnv("XERO_CLIENT_ID");
  const clientSecret = requireEnv("XERO_CLIENT_SECRET");
  const redirectUri = requireEnv("XERO_REDIRECT_URI");

  return new XeroClient({
    clientId,
    clientSecret,
    redirectUris: [redirectUri],
    scopes: XERO_SCOPES,
  });
}

// ✅ xero-node requires initialize() before refreshToken/apiCallback/buildConsentUrl
async function ensureXeroInitialized(xero: XeroClient) {
  const anyX = xero as any;
  if (anyX.__initialized) return;
  await xero.initialize();
  anyX.__initialized = true;
}

export async function getAuthedXeroClient() {
  const tokenSet = await getXeroTokens();
  if (!tokenSet) throw new Error("Xero not connected");

  const xero = makeXeroClient();
  await ensureXeroInitialized(xero);

  await xero.setTokenSet(tokenSet);

  // refresh if expired
  const ts = xero.readTokenSet?.();
  const expired = ts?.expired?.() === true;

  // If expired and we can't refresh, force a reconnect with a clear message
  if (expired) {
    const refreshToken = (ts as any)?.refresh_token;
    if (!refreshToken) {
      throw new Error("Xero token expired and no refresh_token is available. Reconnect Xero.");
    }

    const refreshed = await xero.refreshToken();
    await saveXeroTokens(refreshed);
    await xero.setTokenSet(refreshed);
  }

  // tenant
  const cachedTenant = await getXeroTenant();
  if (cachedTenant?.tenantId) {
    return { xero, tenantId: cachedTenant.tenantId, tenantName: cachedTenant.tenantName ?? "" };
  }

  const tenants = await xero.updateTenants();
  if (!tenants?.length) throw new Error("No Xero tenants available");

  const t0 = tenants[0];
  await saveXeroTenant(t0.tenantId, t0.tenantName ?? "");

  return { xero, tenantId: t0.tenantId, tenantName: t0.tenantName ?? "" };
}
