"use client";

import React, { useEffect, useMemo, useState } from "react";
import { PageHeader } from "../../_components/PageHeader";

type ConnStatus = "Connected" | "Not connected";

const LS_XERO_EMPLOYEES = "xero_employees_v1";
const LS_XERO_SYNC_META = "xero_employees_sync_meta_v1";

function btnBase(disabled: boolean): React.CSSProperties {
  return {
    padding: "8px 10px",
    border: "1px solid #2a2a2a",
    borderRadius: 10,
    fontWeight: 800,
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.55 : 1,
    background: "transparent",
    userSelect: "none",
    transition: "transform 120ms ease, box-shadow 120ms ease, background 120ms ease, opacity 120ms ease",
  };
}

function primaryBtn(disabled: boolean): React.CSSProperties {
  return {
    ...btnBase(disabled),
    background: disabled ? "#0b0b0b" : "#111",
    color: "#fff",
    WebkitTextFillColor: "#fff",
    boxShadow: disabled ? "none" : "0 2px 10px rgba(0,0,0,0.18)",
  };
}

function ghostBtn(disabled: boolean): React.CSSProperties {
  return {
    ...btnBase(disabled),
    background: "transparent",
    color: "#111",
    WebkitTextFillColor: "#111",
  };
}

function IntegrationCard({
  name,
  direction,
  status,
  primaryLabel,
  primaryHref,
  primaryOnClick,
  secondaryLabel,
  secondaryDisabled,
  secondaryOnClick,
  hint,
}: {
  name: string;
  direction: string;
  status: ConnStatus;
  primaryLabel: string;
  primaryHref?: string;
  primaryOnClick?: () => void;
  secondaryLabel: string;
  secondaryDisabled: boolean;
  secondaryOnClick?: () => void;
  hint?: string;
}) {
  return (
    <div style={{ border: "1px solid #2a2a2a", borderRadius: 14, padding: 14 }}>
      <div style={{ fontWeight: 800, fontSize: 16 }}>{name}</div>
      <div style={{ opacity: 0.8, marginTop: 6 }}>{direction}</div>

      <div style={{ marginTop: 10, fontSize: 12 }}>
        Status: <b>{status}</b>
      </div>

      {hint ? <div style={{ marginTop: 8, fontSize: 12, opacity: 0.8, lineHeight: 1.35 }}>{hint}</div> : null}

      <div style={{ display: "flex", gap: 10, marginTop: 12, flexWrap: "wrap" }}>
        {primaryHref ? (
          <a href={primaryHref} style={{ textDecoration: "none" }}>
            <div style={primaryBtn(false)}>{primaryLabel}</div>
          </a>
        ) : (
          <button style={primaryBtn(false)} onClick={primaryOnClick}>
            {primaryLabel}
          </button>
        )}

        <button
          style={ghostBtn(secondaryDisabled)}
          disabled={secondaryDisabled}
          onClick={secondaryOnClick}
          title={secondaryDisabled ? "Only available when connected" : undefined}
        >
          {secondaryLabel}
        </button>
      </div>
    </div>
  );
}

export default function IntegrationsPage() {
  const [fergusStatus, setFergusStatus] = useState<ConnStatus>("Not connected");
  const [loadingFergus, setLoadingFergus] = useState<boolean>(true);
  const [fergusCompanyId, setFergusCompanyId] = useState<number | null>(null);
  const [showFergusModal, setShowFergusModal] = useState<boolean>(false);
  const [fergusToken, setFergusToken] = useState<string>("");
  const [fergusCompanyInput, setFergusCompanyInput] = useState<string>("");
  const [fergusError, setFergusError] = useState<string>("");

  const [xeroStatus, setXeroStatus] = useState<ConnStatus>("Not connected");
  const [xeroTenantName, setXeroTenantName] = useState<string>("");
  const [loadingXero, setLoadingXero] = useState<boolean>(true);

  useEffect(() => {
    let alive = true;

    setLoadingFergus(true);
    fetch("/api/fergus/status", { cache: "no-store" })
      .then((r) => r.json())
      .then((j) => {
        if (!alive) return;
        const connected = Boolean(j?.connected);
        setFergusStatus(connected ? "Connected" : "Not connected");
        const cid = Number(j?.companyId);
        setFergusCompanyId(Number.isFinite(cid) && cid > 0 ? cid : null);
      })
      .catch(() => {
        if (!alive) return;
        setFergusStatus("Not connected");
        setFergusCompanyId(null);
      })
      .finally(() => {
        if (!alive) return;
        setLoadingFergus(false);
      });

    setLoadingXero(true);
    fetch("/api/xero/status", { cache: "no-store" })
      .then((r) => r.json())
      .then((j) => {
        if (!alive) return;
        const connected = Boolean(j?.connected);
        setXeroStatus(connected ? "Connected" : "Not connected");
        setXeroTenantName(String(j?.tenant?.tenantName ?? ""));
      })
      .catch(() => {
        if (!alive) return;
        setXeroStatus("Not connected");
        setXeroTenantName("");
      })
      .finally(() => {
        if (!alive) return;
        setLoadingXero(false);
      });

    return () => {
      alive = false;
    };
  }, []);

  const fergusConnected = fergusStatus === "Connected";
  const fergusHint = useMemo(() => {
    if (loadingFergus) return "Checking connection…";
    if (fergusConnected) {
      return fergusCompanyId ? `Connected. Company ID: ${fergusCompanyId}.` : "Connected.";
    }
    return "Connect with a Fergus Personal Access Token to pull time entries.";
  }, [loadingFergus, fergusConnected, fergusCompanyId]);

  async function refreshFergusStatus() {
    setLoadingFergus(true);
    try {
      const j = await fetch("/api/fergus/status", { cache: "no-store" }).then((r) => r.json());
      const connected = Boolean(j?.connected);
      setFergusStatus(connected ? "Connected" : "Not connected");
      const cid = Number(j?.companyId);
      setFergusCompanyId(Number.isFinite(cid) && cid > 0 ? cid : null);
    } catch {
      setFergusStatus("Not connected");
      setFergusCompanyId(null);
    } finally {
      setLoadingFergus(false);
    }
  }

  async function connectFergus() {
    setFergusError("");
    const token = fergusToken.trim();
    const companyId = fergusCompanyInput.trim();
    const res = await fetch("/api/fergus/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, companyId: companyId || null }),
    }).catch(() => null);

    if (!res) {
      setFergusError("Network error connecting to Fergus.");
      return;
    }

    const j = await res.json().catch(() => ({}));
    if (!res.ok || !j?.ok) {
      setFergusError(String(j?.error ?? "Failed to connect."));
      return;
    }

    setShowFergusModal(false);
    setFergusToken("");
    setFergusCompanyInput("");
    await refreshFergusStatus();
  }

  async function disconnectFergus() {
    await fetch("/api/fergus/disconnect", { method: "POST" }).catch(() => {});
    await refreshFergusStatus();
  }

  const xeroHint = useMemo(() => {
    if (loadingXero) return "Checking connection…";
    if (xeroStatus === "Connected") {
      return xeroTenantName ? `Connected to ${xeroTenantName}.` : "Connected.";
    }
    return "Xero is push-only: we export timesheets from Pay run.";
  }, [loadingXero, xeroStatus, xeroTenantName]);

  async function disconnectXero() {
    await fetch("/api/xero/disconnect", { method: "POST" }).catch(() => {});
    setXeroStatus("Not connected");
    setXeroTenantName("");

    // Optional: clear Xero employee cache when disconnecting
    try {
      localStorage.removeItem(LS_XERO_EMPLOYEES);
      localStorage.removeItem(LS_XERO_SYNC_META);
    } catch {}
  }

  const xeroConnected = xeroStatus === "Connected";

  return (
    <div>
      <PageHeader title="Integrations" subtitle="Connect import sources and export destination." />

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 12 }}>
        <IntegrationCard
          name="Fergus"
          direction="Import"
          status={fergusStatus}
          primaryLabel={fergusConnected ? "Reconnect" : "Connect"}
          primaryOnClick={() => {
            setFergusError("");
            setShowFergusModal(true);
          }}
          secondaryLabel={fergusConnected ? "Disconnect" : "Configure"}
          secondaryDisabled={!fergusConnected}
          secondaryOnClick={disconnectFergus}
          hint={fergusHint}
        />

        <IntegrationCard
          name="Simpro"
          direction="Import"
          status="Not connected"
          primaryLabel="Connect"
          secondaryLabel="Configure"
          secondaryDisabled={true}
          hint="Later: OAuth / API key."
        />

        <IntegrationCard
          name="Xero"
          direction="Export"
          status={xeroStatus}
          primaryLabel={xeroConnected ? "Reconnect" : "Connect"}
          primaryHref={`/api/xero/connect?returnTo=${encodeURIComponent("/app/payruns")}`}
          secondaryLabel={xeroConnected ? "Disconnect" : "Configure"}
          secondaryDisabled={!xeroConnected}
          secondaryOnClick={disconnectXero}
          hint={xeroHint}
        />
      </div>

      {showFergusModal ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 16,
            zIndex: 50,
          }}
          onClick={() => setShowFergusModal(false)}
        >
          <div
            style={{
              width: "min(640px, 100%)",
              background: "#fff",
              borderRadius: 16,
              border: "1px solid #2a2a2a",
              boxShadow: "0 20px 80px rgba(0,0,0,0.35)",
              padding: 14,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ fontWeight: 900, fontSize: 16 }}>Connect Fergus</div>
            <div style={{ marginTop: 6, opacity: 0.8, fontSize: 13, lineHeight: 1.35 }}>
              Paste a <b>Fergus Personal Access Token</b>. This stays in memory while the server is running (same as your
              current Xero demo store).
            </div>

            <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 800, marginBottom: 6 }}>Personal Access Token</div>
                <input
                  value={fergusToken}
                  onChange={(e) => setFergusToken(e.target.value)}
                  placeholder="pat_..."
                  style={{
                    width: "100%",
                    padding: "10px 12px",
                    borderRadius: 12,
                    border: "1px solid #2a2a2a",
                  }}
                />
              </div>

              <div>
                <div style={{ fontSize: 12, fontWeight: 800, marginBottom: 6 }}>
                  Company ID <span style={{ opacity: 0.7, fontWeight: 600 }}>(optional)</span>
                </div>
                <input
                  value={fergusCompanyInput}
                  onChange={(e) => setFergusCompanyInput(e.target.value)}
                  placeholder="12345"
                  style={{
                    width: "100%",
                    padding: "10px 12px",
                    borderRadius: 12,
                    border: "1px solid #2a2a2a",
                  }}
                />
              </div>

              {fergusError ? <div style={{ fontSize: 12, color: "#b00020", fontWeight: 800 }}>{fergusError}</div> : null}

              <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", flexWrap: "wrap" }}>
                <button style={ghostBtn(false)} onClick={() => setShowFergusModal(false)}>
                  Cancel
                </button>
                <button style={primaryBtn(false)} onClick={connectFergus}>
                  Connect
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      <div style={{ marginTop: 12, border: "1px solid #2a2a2a", borderRadius: 14, padding: 14, opacity: 0.85 }}>
        Later: sync logs, last run time, error details, mappings.
      </div>
    </div>
  );
}
