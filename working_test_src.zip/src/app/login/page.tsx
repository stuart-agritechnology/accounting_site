import Link from "next/link";

export default function LoginPage() {
  return (
    <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24 }}>
      <div style={{ width: 380, border: "1px solid #2a2a2a", borderRadius: 14, padding: 18 }}>
        <h1 style={{ marginTop: 0, marginBottom: 14, fontSize: 24, fontWeight: 800 }}>Log in</h1>

        <label style={{ display: "block", fontSize: 13, opacity: 0.8 }}>Email</label>
        <input style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #2a2a2a", marginBottom: 12 }} />

        <label style={{ display: "block", fontSize: 13, opacity: 0.8 }}>Password</label>
        <input type="password" style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #2a2a2a", marginBottom: 12 }} />

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <label style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 13 }}>
            <input type="checkbox" /> Remember me
          </label>
          <a style={{ fontSize: 13 }}>Forgot password?</a>
        </div>

        <Link
          href="/app"
          style={{
            display: "block",
            textAlign: "center",
            padding: "10px 14px",
            borderRadius: 12,
            border: "1px solid #2a2a2a",
            textDecoration: "none",
          }}
        >
          Log in
        </Link>

        <div style={{ marginTop: 12, fontSize: 12, opacity: 0.8 }}>
          (Temporary) This button just navigates to /app.
        </div>
      </div>
    </main>
  );
}
